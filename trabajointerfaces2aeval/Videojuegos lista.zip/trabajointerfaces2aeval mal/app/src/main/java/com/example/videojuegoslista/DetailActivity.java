package com.example.videojuegoslista;

public class DetailActivity {
}
